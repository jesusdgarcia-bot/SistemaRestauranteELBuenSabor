package com.restauranteelbuensabor.service;

import com.restauranteelbuensabor.model.Factura;
import com.restauranteelbuensabor.model.Pedido;

/**
 * Gestiona la generación de facturas y lleva el consecutivo de numeración.
 */
public class ServicioFacturacion {

    private int proximoNumeroFactura = 1;

    /**
     * Genera una factura para el pedido dado e incrementa el consecutivo.
     *
     * @param pedido Pedido con al menos un producto.
     * @return Factura calculada.
     * @throws IllegalArgumentException si el pedido está vacío.
     */
    public Factura generarFactura(Pedido pedido) {
        if (!pedido.tieneProductos()) {
            throw new IllegalArgumentException("No se puede facturar un pedido vacío.");
        }
        return new Factura(proximoNumeroFactura++, pedido);
    }
}
