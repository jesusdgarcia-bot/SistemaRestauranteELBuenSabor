package com.restauranteelbuensabor.service;

import com.restauranteelbuensabor.model.Producto;

import java.util.Collections;
import java.util.List;

/**
 * Catálogo de productos disponibles en el restaurante.
 * Centraliza los datos de la carta en un único lugar.
 */
public class CatalogoProductos {

    private static final List<Producto> PRODUCTOS = List.of(
            new Producto("Bandeja Paisa",       32_000),
            new Producto("Sancocho de Gallina",  28_000),
            new Producto("Arepa con Huevo",       8_000),
            new Producto("Jugo Natural",           7_000),
            new Producto("Gaseosa",                4_500),
            new Producto("Cerveza Poker",          6_000),
            new Producto("Agua Panela",            3_500),
            new Producto("Arroz con Pollo",       25_000)
    );

    private CatalogoProductos() {
        // Clase utilitaria: no se instancia
    }

    public static List<Producto> getTodos() {
        return Collections.unmodifiableList(PRODUCTOS);
    }

    /**
     * Busca un producto por su posición en la carta (base 1).
     *
     * @param numero Número de producto tal como aparece en la carta (1 al tamaño del catálogo).
     * @return El producto correspondiente.
     * @throws IllegalArgumentException si el número está fuera de rango.
     */
    public static Producto buscarPorNumero(int numero) {
        if (numero < 1 || numero > PRODUCTOS.size()) {
            throw new IllegalArgumentException(
                    "Número de producto inválido. La carta tiene " + PRODUCTOS.size() + " productos.");
        }
        return PRODUCTOS.get(numero - 1);
    }

    public static int totalProductos() {
        return PRODUCTOS.size();
    }
}
