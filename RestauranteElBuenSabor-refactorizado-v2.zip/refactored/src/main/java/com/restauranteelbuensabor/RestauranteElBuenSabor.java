package com.restauranteelbuensabor;

import com.restauranteelbuensabor.model.Factura;
import com.restauranteelbuensabor.model.Pedido;
import com.restauranteelbuensabor.model.Producto;
import com.restauranteelbuensabor.service.CatalogoProductos;
import com.restauranteelbuensabor.service.ServicioFacturacion;
import com.restauranteelbuensabor.ui.ConsolaUI;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * Punto de entrada de la aplicación Restaurante El Buen Sabor.
 *
 * <p>Gestiona el ciclo principal del menú y delega cada responsabilidad
 * a las clases correspondientes: {@link ConsolaUI} para la presentación,
 * {@link ServicioFacturacion} para la lógica financiera y los modelos
 * del paquete {@code model} para los datos.</p>
 */
public class RestauranteElBuenSabor {

    private final Scanner scanner = new Scanner(System.in);
    private final ServicioFacturacion servicioFacturacion = new ServicioFacturacion();

    /** Pedido activo; {@code null} cuando no hay mesa abierta. */
    private Pedido pedidoActual = null;

    public static void main(String[] args) {
        new RestauranteElBuenSabor().iniciar();
    }

    private void iniciar() {
        ConsolaUI.imprimirBienvenida();

        boolean ejecutando = true;
        while (ejecutando) {
            ConsolaUI.imprimirMenu();
            int opcion = leerEntero();

            switch (opcion) {
                case 1 -> ConsolaUI.imprimirCarta();
                case 2 -> agregarProducto();
                case 3 -> verPedido();
                case 4 -> generarFactura();
                case 5 -> nuevaMesa();
                case 0 -> {
                    ejecutando = false;
                    System.out.println("¡Hasta luego!");
                }
                default -> ConsolaUI.imprimirError("Opción no válida. Seleccione entre 0 y 5.");
            }
        }

        scanner.close();
    }

    // -------------------------------------------------------------------------
    // Opciones del menú
    // -------------------------------------------------------------------------

    private void agregarProducto() {
        ConsolaUI.imprimirCarta();

        System.out.print("Número de producto (1-" + CatalogoProductos.totalProductos() + "): ");
        int numeroProducto = leerEntero();

        Producto producto;
        try {
            producto = CatalogoProductos.buscarPorNumero(numeroProducto);
        } catch (IllegalArgumentException e) {
            ConsolaUI.imprimirError(e.getMessage());
            return;
        }

        System.out.print("Cantidad: ");
        int cantidad = leerEntero();
        if (cantidad <= 0) {
            ConsolaUI.imprimirError("La cantidad debe ser mayor a cero.");
            return;
        }

        // Si no hay mesa activa, solicitar número de mesa
        if (pedidoActual == null) {
            System.out.print("Ingrese número de mesa: ");
            int numeroMesa = leerEntero();
            if (numeroMesa <= 0) {
                ConsolaUI.imprimirError("El número de mesa debe ser mayor a cero.");
                return;
            }
            pedidoActual = new Pedido(numeroMesa);
        }

        pedidoActual.agregarProducto(producto, cantidad);
        ConsolaUI.imprimirInfo("Agregado: " + producto.getNombre() + " x" + cantidad);
    }

    private void verPedido() {
        if (!hayPedidoActivo()) return;
        ConsolaUI.imprimirPedido(pedidoActual);
    }

    private void generarFactura() {
        if (!hayPedidoActivo()) return;

        Factura factura = servicioFacturacion.generarFactura(pedidoActual);
        ConsolaUI.imprimirFactura(factura);

        // Cerrar la mesa tras facturar
        pedidoActual = null;
    }

    private void nuevaMesa() {
        pedidoActual = null;
        ConsolaUI.imprimirInfo("Mesa reiniciada. Lista para nuevo cliente.");
    }

    // -------------------------------------------------------------------------
    // Métodos auxiliares
    // -------------------------------------------------------------------------

    private boolean hayPedidoActivo() {
        if (pedidoActual == null || !pedidoActual.tieneProductos()) {
            ConsolaUI.imprimirError("No hay productos en el pedido actual. Use la opción 2 para agregar.");
            return false;
        }
        return true;
    }

    /**
     * Lee un entero de la consola. Si la entrada no es válida devuelve -1 y
     * consume la línea problemática para no bloquear el scanner.
     */
    private int leerEntero() {
        try {
            return scanner.nextInt();
        } catch (InputMismatchException e) {
            scanner.nextLine(); // descartar entrada inválida
            return -1;
        }
    }
}
