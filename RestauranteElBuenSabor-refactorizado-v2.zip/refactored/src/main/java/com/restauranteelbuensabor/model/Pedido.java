package com.restauranteelbuensabor.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

/**
 * Representa el pedido activo de una mesa.
 */
public class Pedido {

    private final int numeroMesa;
    private final List<ItemPedido> items;

    public Pedido(int numeroMesa) {
        if (numeroMesa <= 0) {
            throw new IllegalArgumentException("El número de mesa debe ser mayor a cero.");
        }
        this.numeroMesa = numeroMesa;
        this.items = new ArrayList<>();
    }

    public int getNumeroMesa() {
        return numeroMesa;
    }

    /**
     * Agrega un producto al pedido. Si ya existe, incrementa la cantidad.
     */
    public void agregarProducto(Producto producto, int cantidad) {
        Optional<ItemPedido> itemExistente = items.stream()
                .filter(item -> item.getProducto().getNombre().equals(producto.getNombre()))
                .findFirst();

        if (itemExistente.isPresent()) {
            itemExistente.get().agregarCantidad(cantidad);
        } else {
            items.add(new ItemPedido(producto, cantidad));
        }
    }

    public List<ItemPedido> getItems() {
        return Collections.unmodifiableList(items);
    }

    public boolean tieneProductos() {
        return !items.isEmpty();
    }

    public double calcularSubtotal() {
        return items.stream()
                .mapToDouble(ItemPedido::getSubtotal)
                .sum();
    }

    public int cantidadDeProductosDistintos() {
        return items.size();
    }
}
