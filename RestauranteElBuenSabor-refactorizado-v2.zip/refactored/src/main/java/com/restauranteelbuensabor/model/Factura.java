package com.restauranteelbuensabor.model;

/**
 * Representa el resultado financiero de un pedido.
 *
 * <p>Cada aspecto del cálculo vive en su propio método con nombre descriptivo,
 * de acuerdo con el principio de responsabilidad única (SRP). Los valores se
 * calculan una sola vez en el constructor y se almacenan para no repetir
 * operaciones en cada llamada a los getters.</p>
 */
public class Factura {

    // --- Constantes de negocio con nombres descriptivos ---
    private static final double TASA_IVA               = 0.19;
    private static final double TASA_PROPINA            = 0.10;
    private static final double TASA_DESCUENTO          = 0.05;
    private static final int    MIN_ITEMS_PARA_DESCUENTO = 3;
    private static final double UMBRAL_SUBTOTAL_PROPINA  = 50_000;

    private final int    numero;
    private final Pedido pedido;
    private final double subtotalBruto;
    private final double descuento;
    private final double subtotalNeto;
    private final double iva;
    private final double propina;
    private final double total;

    public Factura(int numero, Pedido pedido) {
        this.numero        = numero;
        this.pedido        = pedido;
        this.subtotalBruto = calcularSubtotal();
        this.descuento     = calcularDescuento(subtotalBruto);
        this.subtotalNeto  = subtotalBruto - descuento;
        this.iva           = calcularIVA(subtotalNeto);
        this.propina       = calcularPropina(subtotalNeto, iva);
        this.total         = calcularTotal(subtotalNeto, iva, propina);
    }

    // --- Métodos de cálculo: una responsabilidad cada uno ---

    /** Suma precio × cantidad de cada ítem del pedido. */
    private double calcularSubtotal() {
        return pedido.calcularSubtotal();
    }

    /**
     * Aplica un descuento del 5 % cuando el pedido tiene más de
     * {@value MIN_ITEMS_PARA_DESCUENTO} productos distintos.
     */
    private double calcularDescuento(double subtotal) {
        boolean aplicaDescuento = pedido.cantidadDeProductosDistintos() > MIN_ITEMS_PARA_DESCUENTO;
        return aplicaDescuento ? subtotal * TASA_DESCUENTO : 0;
    }

    /** Calcula el IVA (19 %) sobre la base ya descontada, según DIAN. */
    private double calcularIVA(double base) {
        return base * TASA_IVA;
    }

    /**
     * Aplica propina del 10 % sobre (subtotal neto + IVA) cuando el subtotal
     * neto supera {@value UMBRAL_SUBTOTAL_PROPINA} pesos.
     */
    private double calcularPropina(double subtotalNeto, double iva) {
        boolean aplicaPropina = subtotalNeto > UMBRAL_SUBTOTAL_PROPINA;
        return aplicaPropina ? (subtotalNeto + iva) * TASA_PROPINA : 0;
    }

    /** Suma subtotal neto + IVA + propina para obtener el total a cobrar. */
    private double calcularTotal(double subtotalNeto, double iva, double propina) {
        return subtotalNeto + iva + propina;
    }

    // --- Getters ---

    public int    getNumero()         { return numero; }
    public Pedido getPedido()         { return pedido; }
    public double getSubtotalBruto()  { return subtotalBruto; }
    public double getDescuento()      { return descuento; }
    public double getSubtotalNeto()   { return subtotalNeto; }
    public double getIva()            { return iva; }
    public double getPropina()        { return propina; }
    public double getTotal()          { return total; }
}
