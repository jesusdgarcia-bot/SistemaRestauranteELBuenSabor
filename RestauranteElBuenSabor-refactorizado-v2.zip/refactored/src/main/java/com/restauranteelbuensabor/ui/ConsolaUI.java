package com.restauranteelbuensabor.ui;

import com.restauranteelbuensabor.model.Factura;
import com.restauranteelbuensabor.model.ItemPedido;
import com.restauranteelbuensabor.model.Pedido;
import com.restauranteelbuensabor.model.Producto;
import com.restauranteelbuensabor.service.CatalogoProductos;

import java.util.List;

/**
 * Responsable exclusivamente de imprimir información en consola.
 * No realiza cálculos ni modifica estado.
 */
public class ConsolaUI {

    // --- Datos del establecimiento en un único lugar ---
    private static final String NOMBRE_RESTAURANTE = "RESTAURANTE EL BUEN SABOR";
    private static final String DIRECCION          = "Calle 15 #8-32, Valledupar";
    private static final String NIT                = "900.123.456-7";

    private static final String LINEA_DOBLE  = "========================================";
    private static final String LINEA_SIMPLE = "----------------------------------------";

    private ConsolaUI() {
        // Clase utilitaria: no se instancia
    }

    // --- Método reutilizable para el encabezado del restaurante ---

    /** Imprime el encabezado oficial del restaurante (nombre, dirección y NIT). */
    private static void imprimirEncabezado() {
        System.out.println(LINEA_DOBLE);
        System.out.println("    " + NOMBRE_RESTAURANTE);
        System.out.println("    " + DIRECCION);
        System.out.println("    NIT: " + NIT);
        System.out.println(LINEA_DOBLE);
    }

    // --- Métodos públicos de presentación ---

    public static void imprimirBienvenida() {
        imprimirEncabezado();
    }

    public static void imprimirMenu() {
        System.out.println();
        System.out.println("1. Ver carta");
        System.out.println("2. Agregar producto al pedido");
        System.out.println("3. Ver pedido actual");
        System.out.println("4. Generar factura");
        System.out.println("5. Nueva mesa");
        System.out.println("0. Salir");
        System.out.println(LINEA_DOBLE);
        System.out.print("Seleccione una opción: ");
    }

    public static void imprimirCarta() {
        List<Producto> productos = CatalogoProductos.getTodos();
        imprimirEncabezado();
        System.out.println("    --- NUESTRA CARTA ---");
        System.out.println(LINEA_DOBLE);
        for (int i = 0; i < productos.size(); i++) {
            System.out.printf("%d. %s%n", i + 1, productos.get(i));
        }
        System.out.println(LINEA_DOBLE);
    }

    public static void imprimirPedido(Pedido pedido) {
        System.out.println("--- PEDIDO ACTUAL  (Mesa " + pedido.getNumeroMesa() + ") ---");
        for (ItemPedido item : pedido.getItems()) {
            System.out.printf("%-20s x%-6d $%,.0f%n",
                    item.getProducto().getNombre(),
                    item.getCantidad(),
                    item.getSubtotal());
        }
        System.out.println(LINEA_SIMPLE);
        System.out.printf("%-27s $%,.0f%n", "Subtotal:", pedido.calcularSubtotal());
    }

    public static void imprimirFactura(Factura factura) {
        Pedido pedido = factura.getPedido();

        imprimirEncabezado();
        System.out.printf("FACTURA No. %03d  |  Mesa %d%n",
                factura.getNumero(), pedido.getNumeroMesa());
        System.out.println(LINEA_SIMPLE);

        for (ItemPedido item : pedido.getItems()) {
            System.out.printf("%-20s x%-6d $%,.0f%n",
                    item.getProducto().getNombre(),
                    item.getCantidad(),
                    item.getSubtotal());
        }

        System.out.println(LINEA_SIMPLE);
        System.out.printf("%-27s $%,.0f%n", "Subtotal bruto:", factura.getSubtotalBruto());

        if (factura.getDescuento() > 0) {
            System.out.printf("%-27s -$%,.0f%n", "Descuento (5%):", factura.getDescuento());
            System.out.printf("%-27s $%,.0f%n",  "Subtotal neto:",  factura.getSubtotalNeto());
        }

        System.out.printf("%-27s $%,.0f%n", "IVA (19%):", factura.getIva());

        if (factura.getPropina() > 0) {
            System.out.printf("%-27s $%,.0f%n", "Propina (10%):", factura.getPropina());
        }

        System.out.println(LINEA_SIMPLE);
        System.out.printf("%-27s $%,.0f%n", "TOTAL:", factura.getTotal());
        System.out.println(LINEA_DOBLE);
        System.out.println("¡Gracias por su visita!");
        System.out.println(NOMBRE_RESTAURANTE + " - " + DIRECCION);
        System.out.println(LINEA_DOBLE);
    }

    public static void imprimirError(String mensaje) {
        System.out.println("⚠  " + mensaje);
    }

    public static void imprimirInfo(String mensaje) {
        System.out.println("✓  " + mensaje);
    }
}
